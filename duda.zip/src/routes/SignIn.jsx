const SignIn = () => {
  return <div>SignIn</div>;
};

export default SignIn;

import styles from "./Info.module.css";
import png from "../../assets/png.png";


const Info = () => {

  return (
    <div className={styles.info}>
      <div className={styles.Cont}>
      
      </div>
      <img src={png} alt="" />
    </div>
  );
};

export default Info;
